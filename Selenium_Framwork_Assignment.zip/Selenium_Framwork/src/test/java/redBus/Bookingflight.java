package redBus;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import driver.LaunchDriver;
import driver.reusableData;
import seleniumActions.SeleniumUIActions;

//import driver.LaunchDriver;

public class Bookingflight extends LaunchDriver
{
	
	@BeforeMethod
	public void launchurl()
	{
		LaunchDriver.readDriver(reusableData.driverPath, reusableData.appURL);
	}
	
	
	@Test
	public void searchFlight() throws Exception
	{
		
		LaunchDriver.maximizeBrowser();
		SeleniumUIActions.enterEmail();
		SeleniumUIActions.enterPassword();
		SeleniumUIActions.clickSignin();
		//LaunchDriver.closeBrowser();
		//LaunchDriver.quitBrowser();
	}
	
	@Test
	public void bookFlight() throws Exception
	{
		
		SeleniumUIActions.enterEmail();
		SeleniumUIActions.enterPassword();
		SeleniumUIActions.clickSignin();
		//LaunchDriver.closeBrowser();
		//LaunchDriver.quitBrowser();
	}
	
	
}
