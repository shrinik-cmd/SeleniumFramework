package readProperties;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReaderFile 
{
	public static String readORProperties(String xpath) throws IOException 
	{
		File file=new File("C:\\Users\\Dell\\Selenium\\Selenium_Framwork\\PropertiesFile\\OR.properties");
		FileInputStream stream=new FileInputStream(file);
		Properties prop=new Properties();
		prop.load(stream);
		String readXPath=prop.getProperty(xpath);
		return readXPath;
	}

}
