package seleniumActions;

import java.io.IOException;

import org.openqa.selenium.By;

import driver.LaunchDriver;
import readProperties.ReaderFile;

public class SeleniumUIActions 
{
	public static void enterEmail() throws Exception 
	{
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Demosite.Emailaddress.input"))).sendKeys("abc@gmail.com");	
	}
	
	public static void enterPassword() throws Exception 
	{
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Demosite.Password.input"))).sendKeys("abc123");	
	}
	
	public static void clickSignin() throws Exception 
	{
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Demosite.LoginBtn.input"))).click();	
	}

}
