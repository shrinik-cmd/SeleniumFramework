package seleniumActions;

import java.io.IOException;

import org.openqa.selenium.By;

import driver.LaunchDriver;
import readProperties.ReaderFile;

public class SeleniumUIActions 
{
	public static void enterName() throws Exception 
	{
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Demosite.Emailaddress.input"))).sendKeys("abc@gmail.com");	
	}

}
