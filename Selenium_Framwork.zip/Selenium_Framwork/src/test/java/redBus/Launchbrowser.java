package redBus;

import org.testng.annotations.Test;

import driver.LaunchDriver;
import driver.reusableData;
import seleniumActions.SeleniumUIActions;

//import driver.LaunchDriver;

public class Launchbrowser extends LaunchDriver
{
	@Test
	public void launchbrowser() throws Exception
	{
		LaunchDriver.readDriver(reusableData.driverPath, reusableData.appURL);
		LaunchDriver.maximizeBrowser();
		SeleniumUIActions.enterName();

	//	LaunchDriver.closeBrowser();
	//	LaunchDriver.quitBrowser();
	}
	
}
