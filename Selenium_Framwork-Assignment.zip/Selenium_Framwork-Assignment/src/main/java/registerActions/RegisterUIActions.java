package registerActions;

import org.openqa.selenium.By;

import driver.LaunchDriver;
import readProperties.ReaderFile;

public class RegisterUIActions 
{
	public static void enterAllInfo() throws Exception 
	{
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.Contact.fname"))).sendKeys("Shri");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.Contact.lname"))).sendKeys("Rasure");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.Contact.phone"))).sendKeys("12345");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.Contact.email"))).sendKeys("shri@gmail.com");
		
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.MailingInfo.address"))).sendKeys("abc, 123");		
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.MailingInfo.city"))).sendKeys("Pune");		
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.MailingInfo.state"))).sendKeys("MH");		
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.MailingInfo.pincode"))).sendKeys("411011");
		
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.UserInfo.email"))).sendKeys("ShriNik");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.UserInfo.password"))).sendKeys("12345");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.UserInfo.confirmpassword"))).sendKeys("12345");
		
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.SUBMITButton"))).click();
	}
	
	
	
	/*
	public static void enterMailingInfo() throws Exception 
	{
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.MailingInfo.address"))).sendKeys("abc, 123");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.MailingInfo.city"))).sendKeys("Pune");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.MailingInfo.state"))).sendKeys("MH");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.MailingInfo.pincode"))).sendKeys("411011");
	}

	public static void enterUserInfo() throws Exception 
	{
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.UserInfo.email"))).sendKeys("shriNik");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.UserInfo.password"))).sendKeys("Rasure");
		LaunchDriver.driver.findElement(By.xpath(ReaderFile.readORProperties("Guru.Register.UserInfo.confirmpassword"))).sendKeys("12345");
	}
	*/

}
