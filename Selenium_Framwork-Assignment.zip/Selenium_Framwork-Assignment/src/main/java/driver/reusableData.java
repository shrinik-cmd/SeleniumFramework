package driver;

public interface reusableData {

	public static String appURL="https://demo.guru99.com/test/login.html";
	public static String appRegisterURL="https://demo.guru99.com/test/newtours/register.php";
	public static String driverPath="C:\\Users\\Dell\\Selenium\\Selenium_Framwork\\seleniumDrivers\\chromedriver.exe";
	
}
