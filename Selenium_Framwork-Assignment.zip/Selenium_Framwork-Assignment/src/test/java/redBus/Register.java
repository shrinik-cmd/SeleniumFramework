package redBus;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import driver.LaunchDriver;
import driver.reusableData;
import registerActions.RegisterUIActions;

public class Register extends LaunchDriver
{
	@BeforeMethod
	public void launchurl1()
	{
		LaunchDriver.readDriver(reusableData.driverPath, reusableData.appRegisterURL);
		LaunchDriver.maximizeBrowser();
	}
	
	@Test
	public void RegistrationInfo() throws Exception
	{	
		RegisterUIActions.enterAllInfo();
		Thread.sleep(2000);
	}
	
	/*
	@Test
	public void MailingInfo() throws Exception
	{
		RegisterUIActions.enterMailingInfo();
		Thread.sleep(2000);
	}
	
	@Test
	public void UserInfo() throws Exception
	{
		RegisterUIActions.enterUserInfo();
	}
	*/
}
